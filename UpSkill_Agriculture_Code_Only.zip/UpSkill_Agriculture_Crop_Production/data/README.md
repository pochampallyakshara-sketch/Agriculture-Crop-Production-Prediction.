# Dataset

Place your approved Indian crop-production CSV here as `crop_production.csv`.

The weekly reports describe a dataset sourced from data.gov.in covering 2001–2014 and containing fields such as Crop, Variety, State, Quantity, Production, Season, Unit, Cost and Recommended Zone.

The dataset itself was not included with the supplied weekly reports. Obtain it from the approved source and verify its licence, column names, units and provenance before training. Do not mix incompatible units without normalization.
