"""
Crop Production Prediction in India
Run: python src/train_model.py --data data/crop_production.csv
Expected target column: Production
The script normalizes common column names and builds a leakage-conscious sklearn pipeline.
"""
from __future__ import annotations
import argparse
import re
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor

def clean_name(value):
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")

def parse_numeric(series):
    # Converts strings such as "1,250" to numeric. Unit conversions must be verified
    # against the source dataset before combining different measurement units.
    return pd.to_numeric(series.astype(str).str.replace(",", "", regex=False)
                         .str.replace(r"[^0-9eE.+-]", "", regex=True), errors="coerce")

def load_dataset(path):
    df = pd.read_csv(path)
    df.columns = [clean_name(c) for c in df.columns]
    aliases = {
        "crop_name":"crop", "state_name":"state", "crop_year":"year",
        "crop_production":"production", "prod":"production",
        "quantity_produced":"quantity", "cultivation_cost":"cost",
        "recommended_zone":"recommended_zone"
    }
    df = df.rename(columns={c: aliases[c] for c in df.columns if c in aliases})
    if "production" not in df.columns:
        raise ValueError("Could not find target column 'Production'. Please check the CSV column names.")
    for col in df.columns:
        if col in {"quantity", "production", "cost", "year", "area", "yield"}:
            df[col] = parse_numeric(df[col])
    df = df.drop_duplicates()
    df = df.dropna(subset=["production"])
    df = df[df["production"] >= 0]
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/crop_production.csv")
    parser.add_argument("--output", default="artifacts")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--random-state", type=int, default=42)
    args = parser.parse_args()

    df = load_dataset(args.data)
    target = "production"
    # Avoid using direct derivatives of the target as predictors.
    excluded = {target, "yield", "production_per_area"}
    features = [c for c in df.columns if c not in excluded]
    if not features:
        raise ValueError("No usable predictor columns found.")

    categorical = [c for c in features if df[c].dtype == "object" or str(df[c].dtype) == "category"]
    numeric = [c for c in features if c not in categorical]
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore"))
    ])
    prep = ColumnTransformer([
        ("numeric", numeric_pipe, numeric),
        ("categorical", categorical_pipe, categorical)
    ], remainder="drop")

    X = df[features]
    y = df[target]
    # Log-transform the target to reduce skew; predictions are converted back to original scale.
    use_log = bool((y >= 0).all())
    y_model = np.log1p(y) if use_log else y
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_model, test_size=args.test_size, random_state=args.random_state
    )

    models = {
        "LinearRegression": LinearRegression(),
        "DecisionTree": DecisionTreeRegressor(random_state=args.random_state, max_depth=16),
        "RandomForest": RandomForestRegressor(
            n_estimators=250, random_state=args.random_state, n_jobs=-1,
            min_samples_leaf=2
        )
    }
    results = []
    fitted = {}
    for name, reg in models.items():
        pipe = Pipeline([("preprocessor", prep), ("model", reg)])
        pipe.fit(X_train, y_train)
        pred_t = pipe.predict(X_test)
        y_true = np.expm1(y_test) if use_log else y_test
        y_pred = np.maximum(0, np.expm1(pred_t)) if use_log else pred_t
        results.append({
            "model": name,
            "MAE": float(mean_absolute_error(y_true, y_pred)),
            "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
            "R2": float(r2_score(y_true, y_pred))
        })
        fitted[name] = pipe

    metrics = pd.DataFrame(results).sort_values("RMSE")
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    metrics.to_csv(out/"model_metrics.csv", index=False)
    best_name = str(metrics.iloc[0]["model"])
    joblib.dump({
        "pipeline": fitted[best_name],
        "features": features,
        "target": target,
        "use_log_target": use_log,
        "model_name": best_name
    }, out/"crop_production_model.joblib")
    print("\nModel evaluation (test split):")
    print(metrics.to_string(index=False))
    print(f"\nSaved best model by test RMSE: {best_name}")
    print(f"Artifacts saved to: {out.resolve()}")
    print("Note: metrics are generated only when you run this script on your dataset.")

if __name__ == "__main__":
    main()
