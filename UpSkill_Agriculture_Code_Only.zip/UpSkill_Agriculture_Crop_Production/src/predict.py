"""Example prediction utility. Requires a trained artifacts/crop_production_model.joblib."""
import argparse
import joblib
import pandas as pd

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="artifacts/crop_production_model.joblib")
    parser.add_argument("--input", required=True, help="CSV containing the same predictor columns used during training")
    parser.add_argument("--output", default="predictions.csv")
    args = parser.parse_args()
    bundle = joblib.load(args.model)
    data = pd.read_csv(args.input)
    data.columns = [c.strip().lower().replace(" ", "_") for c in data.columns]
    missing = [c for c in bundle["features"] if c not in data.columns]
    if missing:
        raise ValueError(f"Input file is missing required feature columns: {missing}")
    pred = bundle["pipeline"].predict(data[bundle["features"]])
    if bundle["use_log_target"]:
        import numpy as np
        pred = np.maximum(0, np.expm1(pred))
    result = data.copy()
    result["predicted_production"] = pred
    result.to_csv(args.output, index=False)
    print(f"Saved predictions to {args.output}")

if __name__ == "__main__":
    main()
